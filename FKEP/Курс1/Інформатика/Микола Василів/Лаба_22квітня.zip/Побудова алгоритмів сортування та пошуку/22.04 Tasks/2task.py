a = 1
while a <= 10:
    square = a ** 2
    print(square)
    a += 1
