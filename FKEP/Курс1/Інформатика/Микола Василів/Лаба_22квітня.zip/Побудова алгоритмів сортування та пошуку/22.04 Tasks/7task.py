x = -4.0

while x <= 4.0:
    y = x**2 - 2*x + 1
    print(x, " = ", y)
    
    x += 0.5
