for i in range(10, 21):
    print(f"Квадрат числа {i}: {i ** 2}")
