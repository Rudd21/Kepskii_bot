print("Степені двійки від 0 до 10:")
for i in range(11):
    result = 2 ** i
    print("2^" + str(i) + " = " + str(result))
