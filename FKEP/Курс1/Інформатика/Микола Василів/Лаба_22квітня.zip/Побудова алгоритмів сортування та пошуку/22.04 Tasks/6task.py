a = int(input("Введіть початок діапазону: "))
b = int(input("Введіть кінець діапазону: "))

if b < a:
    print("Помилка: кінець діапазону менший за початок.")
else:
    total = 0
    number = a
    while number <= b:
        if number % 2 != 0: 
            total += number
        number += 1

    print("Сума непарних чисел у заданому діапазоні:", total)
