a = float(input("Введіть a: "))
b = float(input("Введіть b: "))

if a > b:
    print("Помилка")
else:
    number = int(a)
    while number <= b:
        print(number)
        number += 1
