a = 0
while a < 10:
    print("Яцков Тарас")
    a += 1
