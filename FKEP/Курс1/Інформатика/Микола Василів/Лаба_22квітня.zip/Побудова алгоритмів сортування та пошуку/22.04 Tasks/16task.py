max_number = None

for i in range(1, 9):
    num = float(input(f"Введіть число {i}: "))
    if max_number is None or num > max_number:
        max_number = num

print(f"Найбільше число: ", max_number)
