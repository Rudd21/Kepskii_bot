count = 0
num = 2

while count < 25:
    prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            prime = False
            break
    if prime:
        prime_plus_two = True
        for i in range(2, int((num + 2) ** 0.5) + 1):
            if (num + 2) % i == 0:
                prime_plus_two = False
                break
        if prime_plus_two:
            print((num, num + 2))
            count += 1
    num += 1
