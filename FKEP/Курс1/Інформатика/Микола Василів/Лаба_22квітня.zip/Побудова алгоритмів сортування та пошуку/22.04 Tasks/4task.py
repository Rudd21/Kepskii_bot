import math

A = int(input("Введіть значення A"))
x = float(2.0)
while x <= 4.0:
    x+=0.2
    print(math.sin(A*x)+math.sqrt(((3*x)**2)-(5*x)+2))
