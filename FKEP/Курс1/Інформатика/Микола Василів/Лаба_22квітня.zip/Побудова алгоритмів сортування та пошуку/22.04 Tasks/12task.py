count = 0
num = 1

print("Таблиця квадратів перших 5 непарних чисел:")
while count < 5:
    if num % 2 != 0:
        square = num ** 2
        print(f"{num} ^ 2 = {square}")
        count += 1
    num += 1
