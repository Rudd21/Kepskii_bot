b = []
i = 1
while i <= 10:
    b_i = int(input(f"Введіть значення b{i}: "))
    b.append(b_i)
    i += 1

sum_over_20 = 0
for num in b:
    if num > 20:
        sum_over_20 += num

sum_under_50 = 0
for num in b:
    if num < 50:
        sum_under_50 += num

is_sum_even = sum_under_50 % 2 == 0

print("Сума чисел, більших за 20:", sum_over_20)
print("Сума чисел, менших за 50:", sum_under_50)
print("Чи є сума чисел, менших за 50, парною:", "Так" if is_sum_even else "Ні")
print("Вірно, що сума чисел, більших за 20, перевищує 100:", "Так" if sum_over_20 > 100 else "Ні")
