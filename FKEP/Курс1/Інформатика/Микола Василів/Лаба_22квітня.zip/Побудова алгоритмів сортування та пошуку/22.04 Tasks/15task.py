count = 0
total = 0

while True:
    num = float(input("Введіть число (або введіть 0, щоб завершити): "))
    if num == 0:
        break
    elif num < 0:
        print("Будь ласка, введіть додатнє число.")
        continue
    count += 1
    total += num

if count == 0:
    print("Ви не ввели жодного додатнього числа.")
else:
    average = total / count
    print("Сума введених чисел: "{total})
    print("Середнє арифметичне: "{average})
