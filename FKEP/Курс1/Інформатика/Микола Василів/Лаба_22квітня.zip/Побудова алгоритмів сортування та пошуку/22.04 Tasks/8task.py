age = int(input("Введіть ваш вік: "))
retirement_age = 60

if age >= retirement_age:
    print("Ви вже на пенсії!")
else:
    years_left = retirement_age - age
    print("До виходу на пенсію залишилося ",years_left, " років.")
