min_number = None

for i in range(1, 11):
    num = float(input(f"Введіть число {i}: "))
    if min_number is None or num < min_number:
        min_number = num

print(f"Найменше число: {min_number}")
