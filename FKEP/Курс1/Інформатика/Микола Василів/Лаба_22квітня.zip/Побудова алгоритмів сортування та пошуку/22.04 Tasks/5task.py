numbers = input("Введіть послідовність цілих чисел, розділену пробілами: ").split()

index = 0
while index < len(numbers):
    try:
        num = int(numbers[index])
        if num <= 1:
            print(num,  " - не є простим або складеним")
        else:
            is_prime = True
            divisor = 2
            while divisor * divisor <= num:
                if num % divisor == 0:
                    is_prime = False
                    break
                divisor += 1
            if is_prime:
                print(num, "- просте")
            else:
                print(num, " - складене")
    except ValueError:
        print(numbers[index], " не є цілим числом")
    index += 1
