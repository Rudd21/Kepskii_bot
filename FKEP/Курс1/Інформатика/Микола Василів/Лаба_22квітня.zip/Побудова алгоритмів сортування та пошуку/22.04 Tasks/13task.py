count = 0
num = 2

print("Таблиця квадратів перших 5 парних чисел:")
while count < 5:
    square = num ** 2
    print(f"{num} ^ 2 = {square}")
    count += 1
    num += 2
