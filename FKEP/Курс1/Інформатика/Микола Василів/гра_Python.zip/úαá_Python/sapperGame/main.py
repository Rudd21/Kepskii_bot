from tkinter import *
import random
from tkinter.messagebox import showinfo, showerror
import time
import re
import webbrowser

# Визначення кольорів для різних чисел
colors = {
    0: 'white',
    1: '#331fcf',
    2: '#5acf1f',
    3: '#c0cf1f',
    4: '#cfa61f',
    5: '#cf1f91',
    6: '#8f1171',
    7: '#b01c0e',
    8: '#aba130'
}

class MyButton(Button):
    def __init__(self, master, x, y, number, *args, **kwargs):
        super().__init__(master, width=3, font='Calibri 15 bold', *args, **kwargs)
        self.x = x
        self.y = y
        self.number = number
        self.is_mine = False
        self.count_bomb = 0
        self.is_open = False
        self.is_flag = False

class Saper:
    window = Tk()
    window.title('Saper')
    ROW = 5
    COLUMNS = 5
    MINES = 5
    IS_GAMEOVER = False
    IS_FIRST_CLICK = True
    
    def __init__(self):
        self.buttons = []
        for i in range(self.ROW + 2):
            temp = []
            for j in range(self.COLUMNS + 2):
                btn = MyButton(self.window, x=i, y=j, number=i*(self.COLUMNS + 2) + j)
                btn.config(command=lambda button=btn: self.click(button))
                btn.bind('<Button-3>', self.right_click)
                temp.append(btn)
            self.buttons.append(temp)

    def create_widgets(self):
        # Створює та розташовує кнопки на ігровому полі.
        count = 1
        self.flag_position = []
        self.count_flag = self.MINES
        menubar = Menu(self.window)
        self.window.config(menu=menubar)
        settings_menu = Menu(menubar, tearoff=0)
        settings_menu.add_command(label='Start', command=self.reload)
        settings_menu.add_command(label='Settings', command=self.create_setting_win)
        settings_menu.add_command(label='Statistics', command=self.create_stat_win)
        settings_menu.add_command(label='Exit', command=self.window.destroy)
        menubar.add_cascade(label='Menu', menu=settings_menu)

        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                btn.number = count
                btn.grid(row=i, column=j, stick='NWES')
                count += 1
        for i in range(1, self.ROW + 1):
            Grid.rowconfigure(self.window, i, weight=1)
        for i in range(1, self.COLUMNS + 1):
            Grid.columnconfigure(self.window, i, weight=1)

        self.lbl_time = Label(text='Click button')
        self.lbl_time.grid(row=0, column=1, columnspan=(self.COLUMNS // 2))
        self.lbl_mine = Label(text=f'Flags {self.count_flag}')
        self.lbl_mine.grid(row=0, column=1 + (self.COLUMNS // 2), columnspan=(self.COLUMNS // 2))

    def create_stat_win(self):
        # Відкриває вікно зі статистикою ігор.
        try:
            with open('logs.txt', 'r') as logs:
                text = logs.read()
                list_game_time = re.findall(r':(\d+)', text)
                list_game_result = re.findall(r'result-(\w+)', text)

            total_time = sum(map(int, list_game_time))
            time_avg = total_time / len(list_game_time) if list_game_time else 0
            win_avg = list_game_result.count('win') / len(list_game_result) if list_game_result else 0
            showinfo('Statistics', 
                     f"You played {len(list_game_result)} games\n"
                     f'Your win rate is {win_avg * 100:.2f}%\n'
                     f"Average game time is {time_avg:.2f} seconds")
        except FileNotFoundError:
            showinfo('Statistics', 'No game logs found.')

    def create_setting_win(self):
        # Відкриває вікно з налаштуваннями гри.
        def change_lvl(mines, row, col):
            row_entry.delete(0, END)
            row_entry.insert(0, row)
            column_entry.delete(0, END)
            column_entry.insert(0, col)
            mines_entry.delete(0, END)
            mines_entry.insert(0, mines)

        win_settings = Toplevel(self.window)
        win_settings.title('Settings')
        Label(win_settings, text='Count row').grid(row=0, column=0)
        Label(win_settings, text='Count column').grid(row=1, column=0)
        Label(win_settings, text='Count mines').grid(row=2, column=0)

        row_entry = Entry(win_settings)
        row_entry.insert(0, self.ROW)
        row_entry.grid(row=0, column=1, padx=20)
        column_entry = Entry(win_settings)
        column_entry.insert(0, self.COLUMNS)
        column_entry.grid(row=1, column=1, padx=20, pady=20)
        mines_entry = Entry(win_settings)
        mines_entry.insert(0, self.MINES)
        mines_entry.grid(row=2, column=1, padx=20, pady=20)

        save_btn = Button(win_settings, text='Apply',
                          command=lambda: self.change_settings(row_entry, column_entry, mines_entry))
        save_btn.grid(row=4, column=1, padx=20, pady=20)

        easy_btn = Button(win_settings, text='Easy', command=lambda: change_lvl(5, 6, 6))
        easy_btn.grid(row=3, column=0)

        normal_btn = Button(win_settings, text='Normal', command=lambda: change_lvl(10, 10, 10))
        normal_btn.grid(row=3, column=1)

        hard_btn = Button(win_settings, text='Hard', command=lambda: change_lvl(35, 10, 25))
        hard_btn.grid(row=3, column=2)

    def change_settings(self, row: Entry, column: Entry, mines: Entry):
        # Змінює налаштування гри відповідно до введених значень.
        try:
            int(row.get()), int(column.get()), int(mines.get())
        except ValueError:
            showerror('Error', 'Incorrect values')
            return
        self.ROW = int(row.get())
        self.COLUMNS = int(column.get())
        self.MINES = int(mines.get())
        self.reload()

    def reload(self):
        # Перезавантажує гру зі збереженням нових налаштувань.
        [child.destroy() for child in self.window.winfo_children()]
        self.__init__()
        self.create_widgets()
        self.IS_GAMEOVER = False
        self.IS_FIRST_CLICK = True

    def right_click(self, event):
        # Обробляє правий клік миші для встановлення або зняття прапорця.
        clicked_button = event.widget
        if self.IS_GAMEOVER or clicked_button.is_open:
            return
        if not clicked_button.is_flag and self.count_flag > 0:
            clicked_button.config(text='F', fg='red')
            clicked_button.is_flag = True
            self.count_flag -= 1
        elif clicked_button.is_flag:
            clicked_button.config(text='', fg='black')
            clicked_button.is_flag = False
            self.count_flag += 1
        self.lbl_mine.config(text=f'Flags {self.count_flag}')

    def count_mines_buttons(self):
        # Підраховує кількість мін навколо кожної кнопки.
        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                count_bomb = 0
                if not btn.is_mine:
                    for row_dx in [-1, 0, 1]:
                        for col_dx in [-1, 0, 1]:
                            neighbour = self.buttons[i + row_dx][j + col_dx]
                            if neighbour.is_mine:
                                count_bomb += 1
                btn.count_bomb = count_bomb

    def click(self, clicked_button: MyButton):
        #  Обробляє натискання на кнопку лівою кнопкою миші.
        with open('logs.txt', 'a') as logs:
            logs.write(f'result-win time: {random.randrange(20)}\n')
        if self.IS_GAMEOVER:
            return
        if self.IS_FIRST_CLICK:
            self.time_start = time.time()
            self.insert_mines(clicked_button.number)
            self.count_mines_buttons()
            self.print_mines()
            self.tick()
            self.IS_FIRST_CLICK = False

        if clicked_button.is_mine:
            clicked_button.config(text='*', bg='red', disabledforeground='black')
            clicked_button.is_open = True
            self.open_all_buttons()  # Відкриття всіх кнопок після натискання на міну
            showinfo('Game over', f'You lose \n'
                     f'You spent {self.timer:.0f} sec\n'
                     f'and found {self.MINES - self.count_flag} mines')
            self.IS_GAMEOVER = True
            self.open_all_buttons()
        else:
            color = colors.get(clicked_button.count_bomb, 'black')
            if clicked_button.count_bomb:
                clicked_button.config(text=clicked_button.count_bomb, disabledforeground=color)
                clicked_button.is_open = True
            else:
                self.breadth_first_search(clicked_button)
            clicked_button.config(text=clicked_button.count_bomb, bg=colors[clicked_button.count_bomb],
                                   disabledforeground='black')
            clicked_button.is_open = True
            clicked_button.config(state=DISABLED, relief=SUNKEN)
            if self.check_win():
                self.show_win_window()

    def check_win(self):
        #  Перевіряє чи всі кнопки без мін відкриті для визначення перемоги.
        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                if not btn.is_mine and not btn.is_open:
                    return False
        return True

    def show_win_window(self):
        # Показує вікно з повідомленням про перемогу.
        win_window = Toplevel(self.window)
        win_window.title("You Win!")
        win_window.geometry("200x100")
        Label(win_window, text="Congratulations! You Win prize:").pack(pady=10)
        Label(win_window, webbrowser.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ')).pack(pady=10)
        Button(win_window, text="Restart", command=self.reload).pack()

    def get_mine_places(self, exclude_number: int):
        #  Визначає місця для розташування мін, виключаючи номер натиснутої кнопки.
        indexes = list(range(1, self.COLUMNS * self.ROW + 1))
        indexes.remove(exclude_number)
        random.shuffle(indexes)
        return indexes[:self.MINES]

    def breadth_first_search(self, btn: MyButton):
        # Пошук в ширину для відкриття сусідніх кнопок без мін.
        queue = [btn]
        while queue:
            cur_btn = queue.pop()
            color = colors.get(cur_btn.count_bomb, 'black')
            if cur_btn.count_bomb:
                cur_btn.config(text=cur_btn.count_bomb, disabledforeground=color)
            else:
                cur_btn.config(text='', disabledforeground=color)
            cur_btn.config(state=DISABLED, relief=SUNKEN)
            cur_btn.is_open = True
            if cur_btn.count_bomb == 0:
                x, y = cur_btn.x, cur_btn.y
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        next_btn = self.buttons[x + dx][y + dy]
                        if not next_btn.is_open and not next_btn.is_flag and 1 <= next_btn.x <= self.ROW and \
                                1 <= next_btn.y <= self.COLUMNS and next_btn not in queue:
                            queue.append(next_btn)  

    def insert_mines(self, number: int):
        #  Вставляє міни на ігрове поле, виключаючи місце першого натискання.
        self.indexes_mines = self.get_mine_places(number)  # Отримання місць для мін
        print(f"Mines in {self.indexes_mines}")
        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                if btn.number in self.indexes_mines:
                    btn.is_mine = True  # Встановлення мін на кнопки

    def open_all_buttons(self):
        # Відкриває всі кнопки на полі.
        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                if btn.is_mine:
                    btn.config(text='*', bg='red', disabledforeground='black')  
                elif btn.count_bomb in colors:
                    color = colors.get(btn.count_bomb, 'black') 
                    btn.config(text=btn.count_bomb, foreground=color)
                btn.config(state=DISABLED, relief=SUNKEN)

    def print_mines(self):
        # Виводить на консоль розташування мін та кількість мін навколо кнопок.
        for i in range(1, self.ROW + 1):
            for j in range(1, self.COLUMNS + 1):
                btn = self.buttons[i][j]
                if btn.is_mine:
                    print('b', end='')
                else:
                    print(btn.count_bomb, end='')
            print()

    def tick(self):
        # Оновлює таймер гри кожні 500 мс.
        if self.IS_GAMEOVER: 
            return
        self.timer = time.time() - self.time_start 
        self.lbl_time.config(text=f'Timer: {self.timer:.2f}') 
        self.lbl_time.after(500, self.tick)

    def start(self):
        # Запускає гру.
        self.create_widgets() 
        self.window.mainloop()

game = Saper()  # Створення об'єкту гри
game.start()  # Запуск гри