import math

radius = float(input("Введіть радіус кола: "))
side = float(input("Введіть довжину сторони квадрата: "))

diameter = 2 * radius

diagonal = side * math.sqrt(2)

if diameter >= diagonal:
    print("Круг пройде через квадрат.")
else:
    print("Круг не пройде через квадрат.")
