grade = int(input("Введіть оцінку в п'ятибальній системі: "))

if grade == 5:
    print("Відмінно")
elif grade == 4:
    print("Добре")
elif grade == 3:
    print("Задовільно")
else:
    print("Незадовільно")
