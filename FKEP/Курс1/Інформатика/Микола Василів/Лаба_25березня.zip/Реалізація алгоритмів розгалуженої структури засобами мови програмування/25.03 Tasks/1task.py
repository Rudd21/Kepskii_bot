age = int(input("Введіть свій вік: "))

if age >= 18:
    print("Ви маєте право голосу.")
else:
    years_left = 18 - age
    print("Ви отримаєте право голосу через", years_left, "років")
