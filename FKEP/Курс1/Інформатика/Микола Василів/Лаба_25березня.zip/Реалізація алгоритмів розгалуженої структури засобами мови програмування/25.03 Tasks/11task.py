import math

x = float(input("Введіть координату x точки: "))
y = float(input("Введіть координату y точки: "))

R = float(input("Введіть радіус кола: "))

distance = math.sqrt(x ** 2 + y ** 2)

if distance < R:
    print("Точка знаходиться всередині кола.")
elif distance == R:
    print("Точка знаходиться на колі.")
else:
    print("Точка знаходиться поза межами кола.")
