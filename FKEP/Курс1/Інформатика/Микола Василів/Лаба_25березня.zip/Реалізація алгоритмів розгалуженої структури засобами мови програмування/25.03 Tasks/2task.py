import math

x1 = float(input("Введіть координату x1: "))
y1 = float(input("Введіть координату y1: "))

x2 = float(input("Введіть координату x2: "))
y2 = float(input("Введіть координату y2: "))

distance1 = math.sqrt(x1**2 + y1**2)
distance2 = math.sqrt(x2**2 + y2**2)

if distance1 == distance2:
    print("Точки розміщені на одному колі з центром в початку координат.")
else:
    print("Точки не розміщені на одному колі з центром в початку координат.")
