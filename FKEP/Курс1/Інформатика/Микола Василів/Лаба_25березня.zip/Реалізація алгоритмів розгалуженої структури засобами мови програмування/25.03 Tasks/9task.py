numbers = list(map(int, input("Введіть п'ять цілих чисел через пробіл: ").split()))

even_count = 0
multiple_of_3_count = 0

for num in numbers:
    if num % 2 == 0:
        even_count += 1
    if num % 3 == 0:
        multiple_of_3_count += 1

print("Кількість парних чисел:", even_count)
print("Кількість чисел, кратних 3:", multiple_of_3_count)
