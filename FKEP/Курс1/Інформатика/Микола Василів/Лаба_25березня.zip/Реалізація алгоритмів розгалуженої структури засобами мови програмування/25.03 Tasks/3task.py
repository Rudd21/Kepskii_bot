num1 = float(input("Введіть перше число: "))
num2 = float(input("Введіть друге число: "))
num3 = float(input("Введіть третє число: "))

min_num = min(num1, num2, num3)
max_num = max(num1, num2, num3)

print("Найменше число:", min_num)
print("Найбільше число:", max_num)
