a = float(input("Введіть коефіцієнт a: "))
b = float(input("Введіть коефіцієнт b: "))
c = float(input("Введіть коефіцієнт c: "))
x1 = float(input("Введіть координату x першої точки: "))
y1 = float(input("Введіть координату y першої точки: "))
x2 = float(input("Введіть координату x другої точки: "))
y2 = float(input("Введіть координату y другої точки: "))

y1_parabola = a * x1**2 + b * x1 + c
y2_parabola = a * x2**2 + b * x2 + c

if y1 < y1_parabola and y2 < y2_parabola:
    print("Обидві точки знаходяться поза вітками параболи.")
elif y1 > y1_parabola and y2 > y2_parabola:
    print("Обидві точки знаходяться між вітками параболи.")
else:
    print("Точки знаходяться по обидві сторони віток параболи.")
