alpha1 = float(input("Введіть величину першого кута (в градусах): "))
alpha2 = float(input("Введіть величину другого кута (в градусах): "))

alpha3 = 180 - alpha1 - alpha2

if alpha1 <= 0 or alpha2 <= 0 or alpha3 <= 0:
    print("Невірні кути: сума двох кутів повинна бути меншою за 180 градусів.")
else:
    if alpha1 < 90 and alpha2 < 90 and alpha3 < 90:
        print("Трикутник є гострокутним.")
    elif alpha1 == 90 or alpha2 == 90 or alpha3 == 90:
        print("Трикутник є прямокутним.")
    else:
        print("Трикутник є тупокутним.")
