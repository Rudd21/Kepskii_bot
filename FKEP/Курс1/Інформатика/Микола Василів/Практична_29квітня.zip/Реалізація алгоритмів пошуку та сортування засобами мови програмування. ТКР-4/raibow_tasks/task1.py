import turtle
turtle.shape("turtle")
rainbow=("violet","indigo","blue","green","yellow","orange","red")
turtle.pendown()
turtle.speed(13)
turtle.width(3)
for i in range(1, 50):
    for j in rainbow:
        turtle.color(j)
        turtle.circle(100-2*i)
        turtle.right(360/7)
turtle.mainloop()
