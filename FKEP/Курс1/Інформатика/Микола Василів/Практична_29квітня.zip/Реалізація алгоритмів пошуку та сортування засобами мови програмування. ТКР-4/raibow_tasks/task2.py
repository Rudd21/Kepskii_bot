from tkinter import *
import tkinter.messagebox

def button_click():
    s = 1
    i = 1
    st=str_var.get()
    k = int(st)
    while i <= 10:
        s+=(i-1)*i
        i+=2
    if k <= s:
        tkinter.messagebox.showinfo("Результат", 'Встигне отримати '+ str(s))
    else:
        tkinter.messagebox.showinfo("Результат", "Не встигне отримати ")

window = Tk()
str_var = StringVar()

label = Label(window, text="Введіть потребу заленої маси:")
label.pack()

edit = Entry(window, textvariable = str_var)
edit.pack()

button = Button(window, text='Визначити', command=button_click)
button.pack(pady = 8)

window.mainloop()
