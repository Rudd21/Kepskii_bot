from turtle import *
color('red')
width(2)
for x in range(1,100,4):
    circle(x)
    left(92)
