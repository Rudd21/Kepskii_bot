x = 1
while x <= 9:
    y = 1
    while y <= 19:
        z = 1
        while z <= 99:
            cost = 100 * x + 50 * y + 10 * z
            if cost == 1000:
                print("цукерки = ", x, "; вафлі = ", y, "; печиво = ", z)
            z = z + 1
        y = y + 1
    x = x + 1
