num_student = int(input("Введіть номер авто "))
if num_student == 1: 
    print("1. Lotus Esprit (1998). Ціна: 55,195$")
elif num_student == 2:
    print("2. Lancia Stratos (1972). Ціна: 145,000$")
elif num_student == 3:
    print("3. Ferrari Testarossa (1988). Ціна: 110,000$")
elif num_student == 4:
    print("4. De Tomaso Pantera (1972). Ціна: 57,990$")    
else:
    print("Такого нема")
