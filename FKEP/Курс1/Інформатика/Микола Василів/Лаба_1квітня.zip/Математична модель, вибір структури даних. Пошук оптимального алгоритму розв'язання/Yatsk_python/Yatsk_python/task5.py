days_of_week = ['Ukr: Понеділок. Eng: Monday', 'Ukr: Вівторок. Eng: Tuesday', 'Ukr: Середа. Eng: Wendsday', 'Ukr: Четвер. Eng: Thursday', "Ukr: П'ятниця. Eng: Friday", 'Ukr: Субота. Eng: Saturday', 'Ukr: Неділя. Eng: Sunday']

number = int(input("Введіть номер дня тижня: "))

if 1 <= number <= 7:
    print("День тижня:", days_of_week[number - 1])
else:
    print("Некоректний номер")
