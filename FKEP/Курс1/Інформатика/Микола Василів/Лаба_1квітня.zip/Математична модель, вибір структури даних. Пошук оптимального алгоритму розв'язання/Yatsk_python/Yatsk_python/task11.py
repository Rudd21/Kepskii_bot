week_days = {
    1: ('Понеділок', 4),
    2: ('Вівторок', 4),
    3: ('Середа', 3),
    4: ('Четвер', 3),
    5: ("П'ятниця", 3)
}

day_number = int(input("Введіть номер дня тижня (1-5): "))

if day_number in week_days:
    day_name, par = week_days[day_number]
    
    print(f"День тижня: {day_name}")
    print(f"Пар в цей день: {par}")
else:
    print("В такі дні у нас немає пар")
