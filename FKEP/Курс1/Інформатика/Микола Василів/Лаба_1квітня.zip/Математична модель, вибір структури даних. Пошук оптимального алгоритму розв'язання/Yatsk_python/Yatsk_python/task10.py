rivers = {
    'Б': ('Бистриця Надвірнянська', 105, 15),
    'С': ('Сіверський Донець', 1053, 29) ,
    'Д': ('Дніпро', 2201, 32)
}

letter = input("Введіть першу літеру назви річки: ").upper()

if letter in rivers:
    river_name, length, tributaries = rivers[letter]
    
    print(f"Назва річки: {river_name}")
    print(f"Довжина: {length} км")
    print(f"Кількість приток: {tributaries}")
else:
    print("Річки з такою першою літерою не знайдено.")
