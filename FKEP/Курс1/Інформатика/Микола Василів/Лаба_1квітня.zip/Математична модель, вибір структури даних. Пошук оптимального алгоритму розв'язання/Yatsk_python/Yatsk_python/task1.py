num_student = int(input("Введіть номер студента "))
if num_student == 1:
    print("1. Вадим Багира")
elif num_student == 2:
    print("2. Галабурда Олександр")
elif num_student == 20:
    print("20. Яцков Тарас")
elif num_student == 15:
    print("15. Мислюк Олександ")
elif num_student == 18:
    print("18. Ткачук Андрій")
else:
    print("Такого нема")
