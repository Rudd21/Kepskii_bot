countries = {
    'У': ('Україна', 'Європа', 603500),
    'С': ('США', 'Північна Америка', 9834000),
    'Ю': ('ЮАР', 'Африка', 1221037)
}

letter = input("Введіть першу літеру назви країни: ").upper()

if letter in countries:
    country_name, continent, area = countries[letter]
    print(f"Країна: {country_name}")
    print(f"Континент: {continent}")
    print(f"Площа: {area} км²")
else:
    print("Країни з такою першою літерою не знайдено.")
