products = {
    1: ('Продукт1', 100, 50),
    2: ('Продукт2', 200, 30),
    3: ('Продукт3', 150, 20),
    4: ('Продукт4', 120, 40),
    5: ('Продукт5', 180, 25),
    6: ('Продукт6', 90, 35)
}

code = int(input("Введіть числовий код товару: "))

if code in products:
    product_name, price, quantity = products[code]

    print(f"Назва товару: {product_name}")
    print(f"Ціна: {price} грн")
    print(f"Кількість на складі: {quantity} одиниць")
else:
    print("Товару з таким кодом не знайдено.")
