num = str(input("Введіть першу букву країни "))
if num == "Н" and "н":
    print("Столиця Берлін")
elif num == "П" and "п":
     print("Столиця Вашава")
elif num == "А" and "а":
     print("Столиця Відень")
elif num == "У" and "у":
     print("Столиця Київ")    
else:
    print("Такої столиці нема")
