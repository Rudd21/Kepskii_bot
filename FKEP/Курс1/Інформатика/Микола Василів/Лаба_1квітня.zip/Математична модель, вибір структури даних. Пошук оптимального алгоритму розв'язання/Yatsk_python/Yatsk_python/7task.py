cities = {
    'К': ('Київ', 2952494, 847),
    'Л': ('Львів', 724314, 182),
    'Н': ('Нью-Йорк', 8336817, 783.8)
}

letter = input("Введіть першу літеру назви міста: ").upper()

if letter in cities:
    city_name, population, area = cities[letter]

    print(f"Місто: {city_name}")
    print(f"Населення: {population} людей")
    print(f"Площа: {area} км²")
else:
    print("Міста немає.")
